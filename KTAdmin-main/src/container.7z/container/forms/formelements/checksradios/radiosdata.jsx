
export const Checkdata1= [
    { id: '1', class1: 'mb-2', class2: '', text: 'Primary' },
    { id: '2', class1: 'mb-2', class2: 'secondary', text: 'Secondary' },
    { id: '3', class1: 'mb-2', class2: 'warning', text: 'Warning' },
    { id: '4', class1: 'mb-2', class2: 'info', text: 'Info' },
    { id: '5', class1: 'mb-2', class2: 'success', text: 'Success' },
    { id: '6', class1: 'mb-2', class2: 'danger', text: 'Danger' },
    { id: '7', class1: 'mb-0', class2: 'dark', text: 'Dark' }
];
