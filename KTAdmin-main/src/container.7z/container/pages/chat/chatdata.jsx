import media13 from "../../../assets/images/media/media-13.jpg";
import media19 from "../../../assets/images/media/media-19.jpg";
import media20 from "../../../assets/images/media/media-20.jpg";
import media52 from "../../../assets/images/media/media-52.jpg";
import media53 from "../../../assets/images/media/media-53.jpg";
import media56 from "../../../assets/images/media/media-56.jpg";
import media63 from "../../../assets/images/media/media-63.jpg";
import media64 from "../../../assets/images/media/media-64.jpg";
import media62 from "../../../assets/images/media/media-62.jpg";

export const Photosmediadata = [
    { id: 1, src: media56 },
    { id: 2, src: media52 },
    { id: 3, src: media53 },
    { id: 4, src: media62 },
    { id: 5, src: media63 },
    { id: 6, src: media64 },
    { id: 7, src: media13 },
    { id: 8, src: media19 },
    { id: 9, src: media20 },
];
