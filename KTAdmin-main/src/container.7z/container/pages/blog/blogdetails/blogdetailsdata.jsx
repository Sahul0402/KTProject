
export const Populartagsdata =[
    {id:1, text:'blogger'},
    {id:2, text:'styleblogger'},
    {id:3, text:'livecolorfully'},
    {id:4, text:'amwriting'},
    {id:5, text:'analytics'},
    {id:6, text:'designblogger'},
    {id:7, text:'picoftheday'},
    {id:8, text:'adventure'},
    {id:9, text:'landscape'},
    {id:10, text:'fitnessgoals'},
    {id:11, text:'foodblogger'},
    {id:12, text:'vegan'},
    {id:13, text:'portrait'},
    {id:14, text:'canonphotography'},
    {id:15, text:'fineart'},
    {id:16, text:'trending'},
    {id:17, text:'lifestyle'}
];

export const Exploretopicsdata=[
    {id:1,title:'N', color:'secondary', text:'Nature', badge:'21'},
    {id:2,title:'S', color:'success', text:'Sports', badge:'16'},
    {id:3,title:'F', color:'warning', text:'Food', badge:'06'},
    {id:4,title:'T', color:'danger', text:'Travel', badge:'18'},
    {id:5,title:'F', color:'primary', text:'Fashion', badge:'09'},
    {id:6,title:'B', color:'info', text:'Beauty', badge:'11'}
];
