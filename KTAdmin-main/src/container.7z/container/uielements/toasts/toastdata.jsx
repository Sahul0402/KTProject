
  export const Colorspinner =[
 {id:1, color1:'primary-light', color2:'primary'},
 {id:2, color1:'secondary-light', color2:'secondary'},
 {id:3, color1:'warning-light', color2:'warning'},
 {id:4, color1:'info', color2:'info'},
 {id:5, color1:'success', color2:'success'},
 {id:6, color1:'danger', color2:'danger'},
  ];
