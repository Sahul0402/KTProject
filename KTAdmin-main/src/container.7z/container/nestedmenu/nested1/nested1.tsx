import React from 'react';


const Nested1= () => (
  <>
    Nested1 Component
  </>
);

export default Nested1;
