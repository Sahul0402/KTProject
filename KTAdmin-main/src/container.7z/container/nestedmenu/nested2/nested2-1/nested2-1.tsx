import  React from 'react';


const Nested21 = () => (
  <div>
    Nested21 Component
  </div>
);

export default Nested21;
