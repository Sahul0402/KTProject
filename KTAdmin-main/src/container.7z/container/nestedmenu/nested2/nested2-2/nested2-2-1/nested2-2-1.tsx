import React from 'react';

const Nested221 = () => (
  <div>
    Nested221 Component
  </div>
);

export default Nested221;
