import  React from 'react';


const Nested222 = () => (
  <div>
    Nested222 Component
  </div>
);

export default Nested222;
