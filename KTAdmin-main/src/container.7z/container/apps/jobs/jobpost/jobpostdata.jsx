
export const Data1=[
 {value:'Development', label:'Development'},
 {value:'Marketing', label:'Marketing'},
 {value:'IT Software', label:'IT Software'}
  ];
  export const Data2=[
{value:'0 - 1 Years', label:'0 - 1 Years'},
{value:'1 - 3 Yearsg', label:'1 - 3 Years'},
{value:'3 - 5 Years', label:'3 - 5Years'}
];
export const Data3=[
{value:'Normal', label:'Normal'},
{value:'Urgent', label:'Urgent'}
];
export const Data4=[
{value:'10', label:'10'},
{value:'20', label:'20'},
{value:'30', label:'30'},
{value:'40', label:'40'}
];
export const Data5=[
{value:'0 - $1,00,000 / Year', label:'0 - $1,00,000 / Year'},
{value:'$1,00,000 - $3,00,000 / Year', label:'$1,00,000 - $3,00,000 / Year'},
{value:'$3,00,000 - $5,00,000 / Year', label:'$3,00,000 - $5,00,000 / Year'}
];
export const Data6=[
{value:'HTML', label:'HTML'},
{value:'CSS', label:'CSS'},
{value:'JavaScript', label:'JavaScript'},
{value:'React', label:'React'}
];
export const Data7=[
 {value:'No Preferences', label:'No Preferences'},
 {value:'Male Only', label:'Male Only'},
 {value:'Female Only', label:'Female Only'}
 ];
export const Data8=[
{value:'English', label:'English'},
{value:'French', label:'French'},
{value:'Arabic', label:'Arabic'},
{value:'Hindi', label:'Hindi'}
];
export const Data9=[
 {value:'Graduate', label:'Graduate'},
 {value:'Diploma', label:'Diploma'},
 {value:'MBA', label:'MBA'},
 {value:'MCA', label:'MCA'}
];

export const Data10=[
{value:'Obligation Pvt.Ltd', label:'Obligation Pvt.Ltd'},
{value:'Voluptatem Pvt.Ltd', label:'Voluptatem Pvt.Ltd'},
{value:'BloomTech.Inc', label:'BloomTech.Inc'},
{value:'Spotech Technical Solutions', label:'Spotech Technical Solutions'}
];
export const Data11=[
{value:'India', label:'India'},
{value:'USA', label:'USA'},
{value:'Germany', label:'Germany'},
{value:'Spain', label:'Spain'},
{value:'Urgentina', label:'Urgentina'}
];
